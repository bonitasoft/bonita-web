import org.bonitasoft.web.extension.rest.RestApiController
import org.bonitasoft.web.extension.rest.RestApiResponse
import org.bonitasoft.web.extension.rest.RestApiResponseBuilder
import org.bonitasoft.web.extension.rest.RestApiContext


import javax.servlet.http.HttpServletRequest

public class IndexRestApi implements RestApiController {


    @Override
    RestApiResponse doHandle(HttpServletRequest request, RestApiResponseBuilder apiResponseBuilder, RestApiContext context){

        return apiResponseBuilder.withResponse("RestResource.groovy!").build()

    }
}
